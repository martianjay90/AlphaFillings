# Parsers

XBRL 및 PDF 데이터 추출기를 포함하는 폴더입니다.

## 파서 목록

- **DART 파서**: 한국 공시 데이터 (XBRL/PDF) 추출
- **SEC 파서**: 미국 SEC 데이터 (XBRL/PDF) 추출
